#define IDC_STATIC -1

#define IDC_FIELD                       1000
#define IDC_DRAW                        1001
#define IDC_PLAY                        1002
#define IDC_HOME                        1005
#define IDC_SOLVE                       1006
#define IDC_CLEAR                       1007
#define IDC_SOLUTIONS                   1008
#define IDC_TIME                        1009
#define IDC_STOP                        1010
#define IDC_SCROLL                      1011
#define IDC_CURSOL                      1013
#define IDC_CLOSE                       1014
#define IDC_READ                        1015
#define IDC_WRITE                       1016
