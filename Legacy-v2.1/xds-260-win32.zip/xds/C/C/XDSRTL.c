/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)XDSRTL.c Oct 28 21:43:06 2024" */
#include "XDSRTL.h"
#define XDSRTL_C_
#include "xmRTS.h"


extern void XDSRTL_Init(PINT argc, PPCHAR argv, long gcauto,
                long gcthreshold, long heaplimit)
{
   X2C_BEGIN(argc, (X2C_ppCHAR)argv, gcauto, gcthreshold, heaplimit);
} /* end XDSRTL_Init() */


extern void XDSRTL_Exit(void)
{
   X2C_EXIT();
} /* end XDSRTL_Exit() */

