/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosFmtIO.c Oct 28 21:43:06 2024" */
#include "xosFmtIO.h"
#define xosFmtIO_C_
#include "xrtsOS.h"

#define spaces "        "


static void outs(const char s[], unsigned long len)
{
   if (len==0UL) return;
   X2C_StdOut(s, len);
} /* end outs() */


extern void X2C_StdOutS(char s[], unsigned long w)
{
   unsigned long l;
   l = 0UL;
   while (s[l]) ++l;
   outs(s, l);
   if (w>l) {
      while (w-l>8UL) {
         outs("        ", 8UL);
         l += 8UL;
      }
      if (w>l) outs("        ", w-l);
   }
} /* end X2C_StdOutS() */


extern void X2C_HexToStr(char s[], unsigned long * pos, unsigned long no)
{
   unsigned long i;
   unsigned long d;
   *pos += 8UL;
   for (i = 0UL; i<=7UL; i++) {
      d = no&15UL;
      no = no/16UL;
      --*pos;
      if (d>9UL) s[*pos] = (char)((65UL+d)-10UL);
      else s[*pos] = (char)(48UL+d);
   } /* end for */
} /* end X2C_HexToStr() */


extern void X2C_StdOutH(unsigned long no, unsigned long w)
{
   char buf[12];
   unsigned long pos;
   pos = 0UL;
   X2C_HexToStr(buf, &pos, no);
   if (w>8UL) {
      while (w>16UL) {
         outs("        ", 8UL);
         w -= 8UL;
      }
      if (w>8UL) outs("        ", w-8UL);
   }
   outs(buf, 8UL);
} /* end X2C_StdOutH() */


extern void X2C_DecToStr(char s[], unsigned long * pos, unsigned long no)
{
   unsigned long i;
   unsigned long l;
   i = 1000000000UL;
   l = 10UL;
   while (i>no) {
      i = i/10UL;
      --l;
   }
   if (l==0UL) l = 1UL;
   *pos += l;
   i = *pos;
   while (l>0UL) {
      --i;
      s[i] = (char)(48UL+no%10UL);
      no = no/10UL;
      --l;
   }
} /* end X2C_DecToStr() */


extern void X2C_StdOutD(unsigned long no, unsigned long w)
{
   char buf[12];
   unsigned long pos;
   pos = 0UL;
   X2C_DecToStr(buf, &pos, no);
   if (w>pos) {
      while (w-pos>8UL) {
         outs("        ", 8UL);
         w -= 8UL;
      }
      if (w>pos) outs("        ", w-pos);
   }
   outs(buf, pos);
} /* end X2C_StdOutD() */

