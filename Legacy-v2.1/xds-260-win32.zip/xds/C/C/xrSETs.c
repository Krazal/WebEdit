/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrSETs.c Oct 28 21:43:06 2024" */
#include "xrSETs.h"
#define xrSETs_C_


extern long X2C_ASH(long a, long b)
{
   if (b>31L) return 0L;
   if (b<-31L) b = -31L;
   return (b >= 0) ? (a << b) : (a >> (-b));
   return 0L;
} /* end X2C_ASH() */


extern short X2C_ASH16(short a, long b)
{
   short n;
   if (b>15L) return 0;
   if (b<-15L) n = -15;
   else n = (short)b;
   return (n >= 0) ? (a << n) : (a >> (-n));
   return 0;
} /* end X2C_ASH16() */


extern signed char X2C_ASH8(signed char a, long b)
{
   signed char n;
   if (b>7L) return 0;
   if (b<-7L) n = -7;
   else n = (signed char)b;
   return (n >= 0) ? (a << n) : (a >> (-n));
   return 0;
} /* end X2C_ASH8() */


extern unsigned long X2C_ROT(unsigned long a, short length, long n)
{
   unsigned long m;
   m = 0UL;
   m = (length==32) ? 0xFFFFFFFFl : (1l << length)-1;
   if (n>0L) {
      n=n % length;
      return ((a << n) | (a >> (length - n))) & m;
   }
   else {
      n= -n % length;
      return ((a >> n) | (a << (length - n))) & m;
   }
   return 0UL;
} /* end X2C_ROT() */


extern unsigned long X2C_LSH(unsigned long a, short length, long n)
{
   unsigned long m;
   m = 0UL;
   m = (length==32) ? 0xFFFFFFFFl : (1l << length)-1;
   if (n>0L) {
      if (n>=(long)length) return 0UL;
      return (a << n) & m;
   }
   else {
      if (n<=(long) -length) return 0UL;
      return (a >> -n) & m;
   }
   return 0UL;
} /* end X2C_LSH() */

