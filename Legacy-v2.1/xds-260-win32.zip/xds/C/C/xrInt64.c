/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrInt64.c Oct 28 21:43:06 2024" */
#include "xrInt64.h"
#define xrInt64_C_



typedef unsigned long Arr[4];

#define M 0x10000 

#define S 0x7FFF 


extern void X2C_INTTO64(struct X2C_int64 * res, long val)
{
   if (val<0L) res->high = X2C_max_longcard;
   else res->high = 0UL;
   res->low = (unsigned long)val;
} /* end X2C_INTTO64() */


extern void X2C_CARDTO64(struct X2C_int64 * res, unsigned long val)
{
   res->high = 0UL;
   res->low = val;
} /* end X2C_CARDTO64() */


extern char X2C_IsNeg64(struct X2C_int64 a)
{
   return a.high>2147483647UL;
} /* end X2C_IsNeg64() */


static void toArr(Arr a, const struct X2C_int64 val)
{
   a[0U] = val.low&65535UL;
   a[1U] = val.low/65536UL;
   a[2U] = val.high&65535UL;
   a[3U] = val.high/65536UL;
} /* end toArr() */


static void to64(struct X2C_int64 * x, const Arr a)
{
   x->low = a[1U]*65536UL+a[0U];
   x->high = a[3U]*65536UL+a[2U];
} /* end to64() */


static void neg(Arr a)
{
   unsigned long i;
   unsigned long r;
   for (i = 0UL; i<=3UL; i++) {
      a[i] = (65536UL-a[i])-1UL;
   } /* end for */
   r = 1UL;
   i = 0UL;
   while (i<4UL && r) {
      r += a[i];
      a[i] = r&65535UL;
      r = r/65536UL;
      ++i;
   }
} /* end neg() */


static char add(Arr res, const Arr a, const Arr b)
{
   unsigned long i;
   unsigned long r;
   r = 0UL;
   for (i = 0UL; i<=3UL; i++) {
      r = a[i]+b[i]+r;
      res[i] = r&65535UL;
      r = r/65536UL;
   } /* end for */
   return r!=0UL;
} /* end add() */


static void mul(Arr res, unsigned long a, unsigned long b)
{
   unsigned long r;
   unsigned long b1;
   unsigned long b0;
   unsigned long a1;
   unsigned long a0;
   a0 = a&65535UL;
   a1 = a/65536UL;
   b0 = b&65535UL;
   b1 = b/65536UL;
   r = a0*b0;
   res[0U] = r&65535UL;
   r = r/65536UL;
   r += a0*b1+b0*a1;
   res[1U] = r&65535UL;
   r = r/65536UL;
   r += a1*b1;
   res[2U] = r&65535UL;
   res[3U] = r/65536UL;
} /* end mul() */


extern char X2C_UnMinus64(struct X2C_int64 * res, struct X2C_int64 x)
{
   Arr a;
   char s;
   toArr(a, x);
   s = a[3U]>32767UL;
   neg(a);
   if (s==a[3U]>32767UL && (x.high || x.low)) return 1;
   to64(res, a);
   return 0;
} /* end X2C_UnMinus64() */


extern char X2C_ADD64(struct X2C_int64 * res, struct X2C_int64 A,
                struct X2C_int64 B)
{
   Arr r;
   Arr b;
   Arr a;
   char cr;
   char sb;
   char sa;
   toArr(a, A);
   toArr(b, B);
   sa = a[3U]>32767UL;
   sb = b[3U]>32767UL;
   cr = add(r, a, b);
   to64(res, r);
   return sa==sb && r[3U]>32767UL!=sa;
} /* end X2C_ADD64() */


extern char X2C_64TOINT(long * res, struct X2C_int64 x)
{
   *res = (long)x.low;
   return (x.high || x.low>=0x080000000UL)
                && (x.high!=X2C_max_longcard || x.low<0x080000000UL);
} /* end X2C_64TOINT() */


extern char X2C_64TOCARD(unsigned long * res, struct X2C_int64 x)
{
   *res = x.low;
   return x.high!=0UL;
} /* end X2C_64TOCARD() */


extern void X2C_MUL64(struct X2C_int64 * res, long a, unsigned long b)
{
   unsigned long x;
   char sig;
   Arr ra;
   sig = a<0L;
   if (sig) {
      if (a==X2C_min_longint) x = 0x080000000UL;
      else x = (unsigned long) -a;
   }
   else x = (unsigned long)a;
   mul(ra, x, b);
   if (sig) neg(ra);
   to64(res, ra);
} /* end X2C_MUL64() */


extern int X2C_CMP64(struct X2C_int64 a, struct X2C_int64 b)
{
   char bn;
   char an;
   an = a.high>2147483647UL;
   bn = b.high>2147483647UL;
   if (an && !bn) return -1;
   if (bn && !an) return 1;
   if (a.high>b.high) return 1;
   if (a.high<b.high) return -1;
   if (a.low>b.low) return 1;
   if (a.low<b.low) return -1;
   return 0;
} /* end X2C_CMP64() */

