/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrcIncDec64.c Oct 28 21:43:06 2024" */
#include "xrcIncDec64.h"
#define xrcIncDec64_C_
#include "X2C.h"
#include "M2EXCEPTION.h"


extern X2C_INT64 X2C_INC64(X2C_INT64 * x, X2C_INT64 y, X2C_INT64 min0,
                X2C_INT64 max0)
{
   X2C_INT64 i;
   if (y>0i64) {
      if (0x07FFFFFFFFFFFFFFFi64-y<*x) X2C_TRAP(1L);
   }
   else if ((-0x08000000000000000i64)-y>*x) X2C_TRAP(1L);
   i = *x+y;
   if (i<min0 || i>max0) X2C_TRAP(1L);
   *x = i;
   return *x;
} /* end X2C_INC64() */


extern X2C_CARD64 X2C_INCU64(X2C_CARD64 * x, X2C_CARD64 y, X2C_CARD64 min0,
                X2C_CARD64 max0)
{
   X2C_CARD64 i;
   if (0x0FFFFFFFFFFFFFFFFUi64-y<*x) X2C_TRAP(1L);
   i = *x+y;
   if (i<min0 || i>max0) X2C_TRAP(1L);
   *x = i;
   return *x;
} /* end X2C_INCU64() */


extern X2C_INT64 X2C_DEC64(X2C_INT64 * x, X2C_INT64 y, X2C_INT64 min0,
                X2C_INT64 max0)
{
   if (y<0i64) {
      if (0x07FFFFFFFFFFFFFFFi64+y<*x) X2C_TRAP(1L);
   }
   else if ((-0x08000000000000000i64)+y>*x) X2C_TRAP(1L);
   *x -= y;
   if (*x<min0 || *x>max0) X2C_TRAP(1L);
   return *x;
} /* end X2C_DEC64() */


extern X2C_CARD64 X2C_DECU64(X2C_CARD64 * x, X2C_CARD64 y, X2C_CARD64 min0,
                X2C_CARD64 max0)
{
   X2C_CARD64 i;
   if (y>*x) X2C_TRAP(1L);
   i = *x-y;
   if (i<min0 || i>max0) X2C_TRAP(1L);
   *x = i;
   return *x;
} /* end X2C_DECU64() */

