/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosIpts.c Oct 28 21:43:06 2024" */
#include "xosIpts.h"
#define xosIpts_C_


extern void X2C_EnableIpts(void)
{
} /* end X2C_EnableIpts() */


extern void X2C_DisableIpts(void)
{
} /* end X2C_DisableIpts() */


extern void X2C_SaveIptHandler(unsigned long no)
{
} /* end X2C_SaveIptHandler() */


extern void X2C_RestoreIptHandler(unsigned long no)
{
} /* end X2C_RestoreIptHandler() */


extern char X2C_SetIptHandler(unsigned long no)
{
   return 0;
} /* end X2C_SetIptHandler() */

