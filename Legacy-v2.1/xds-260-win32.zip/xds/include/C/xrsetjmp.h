/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
#ifndef xrsetjmp_H_
#define xrsetjmp_H_
#include "X2C.h"
#include "xPOSIX.h"

typedef jmp_buf X2C_jmp_buf;

#define X2C_setjmp setjmp

#define X2C_longjmp longjmp


#endif /* xrsetjmp_H_ */
