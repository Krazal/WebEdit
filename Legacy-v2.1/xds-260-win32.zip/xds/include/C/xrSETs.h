/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
#ifndef xrSETs_H_
#define xrSETs_H_
#include "X2C.h"

extern long X2C_ASH(long, long);

extern short X2C_ASH16(short, long);

extern signed char X2C_ASH8(signed char, long);

extern unsigned long X2C_ROT(unsigned long, short, long);

extern unsigned long X2C_LSH(unsigned long, short, long);


#endif /* xrSETs_H_ */
